    // routes/programRoutes.js
    const express = require('express');
    const router = express.Router(); // Membuat instance router Express
    const programController = require('../controllers/programController'); // Mengimpor controller program

    // Rute POST untuk membuat program baru
    // Contoh: POST /api/programs
    router.post('/', programController.createProgram);

    // Rute GET untuk mengambil semua program
    // Contoh: GET /api/programs
    router.get('/', programController.getAllPrograms);

    // Rute GET untuk mengambil program berdasarkan ID
    // Contoh: GET /api/programs/:id
    router.get('/:id', programController.getProgramById);

    // Rute PUT untuk memperbarui program berdasarkan ID
    // Contoh: PUT /api/programs/:id
    router.put('/:id', programController.updateProgram);

    // Rute DELETE untuk menghapus program berdasarkan ID
    // Contoh: DELETE /api/programs/:id
    router.delete('/:id', programController.deleteProgram);

    module.exports = router; // Mengekspor router
    