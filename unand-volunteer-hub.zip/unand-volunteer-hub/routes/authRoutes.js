    // routes/authRoutes.js
    const express = require('express');
    const router = express.Router(); // Membuat instance router Express
    const authController = require('../controllers/authController'); // Mengimpor controller autentikasi

    // Rute POST untuk login pengguna
    // Ketika permintaan POST datang ke /api/auth/login, fungsi authController.login akan dijalankan
    router.post('/login', authController.login);

    // Rute POST untuk pendaftaran pengguna baru
    // Ketika permintaan POST datang ke /api/auth/register, fungsi authController.register akan dijalankan
    router.post('/register', authController.register);

    module.exports = router; // Mengekspor router
    