const express = require('express');
const router = express.Router(); // Create an instance of the Express router

// Import specific route handlers
const authRoutes = require('./authRoutes');
const programRoutes = require('./programRoutes');
const userRoutes = require('./userRoutes');

// Middleware to check if the user is authenticated and has the correct role
function isAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    } else {
        res.redirect('/login'); // Redirect to login page if not authenticated
    }
}

function isMahasiswa(req, res, next) {
    if (req.isAuthenticated() && req.user.role === 'mahasiswa') {
        return next();
    } else {
        res.redirect('/login'); // Redirect if user is not a Mahasiswa
    }
}

function isPengurus(req, res, next) {
    if (req.isAuthenticated() && req.user.role === 'pengurus') {
        return next();
    } else {
        res.redirect('/login'); // Redirect if user is not a Pengurus
    }
}

function isAdmin(req, res, next) {
    if (req.isAuthenticated() && req.user.role === 'admin') {
        return next();
    } else {
        res.redirect('/login'); // Redirect if user is not an Admin
    }
}

// Auth routes
router.use('/auth', authRoutes); // All authentication routes will be prefixed with '/auth'

// Program routes
router.use('/program', isAuthenticated, programRoutes); // Ensure user is authenticated before accessing program routes

// User routes for Mahasiswa
router.use('/mahasiswa', isMahasiswa, userRoutes); // Ensure user is Mahasiswa before accessing related routes

// User routes for Pengurus
router.use('/pengurus', isPengurus, userRoutes); // Ensure user is Pengurus before accessing related routes

// User routes for Admin
router.use('/admin', isAdmin, userRoutes); // Ensure user is Admin before accessing related routes

module.exports = router;
