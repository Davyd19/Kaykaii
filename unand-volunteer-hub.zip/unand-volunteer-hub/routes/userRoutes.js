    // routes/userRoutes.js
    const express = require('express');
    const router = express.Router(); // Membuat instance router Express
    const userController = require('../controllers/userController'); // Mengimpor controller user

    // Rute GET untuk mengambil semua pengguna
    // Contoh: GET /api/users
    router.get('/', userController.getAllUsers);

    // Rute PUT untuk memperbarui peran (role) pengguna berdasarkan ID
    // Contoh: PUT /api/users/:id/role
    router.put('/:id/role', userController.updateUserRole);

    // Rute DELETE untuk menghapus pengguna berdasarkan ID
    // Contoh: DELETE /api/users/:id
    router.delete('/:id', userController.deleteUser);

    module.exports = router; // Mengekspor router
    