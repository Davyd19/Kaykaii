// server.js
const express = require('express');
const app = express();
const path = require('path');
require('dotenv').config(); // Memuat variabel lingkungan dari file .env

// Menentukan PORT yang akan digunakan server.
const PORT = process.env.PORT || 3000;

// Set view engine ke EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views')); // Tentukan folder views

// Menyajikan file statis (misalnya, CSS, JS, dll)
app.use(express.static(path.join(__dirname, 'public')));

// Rute untuk halaman utama (role selection)
app.get('/', (req, res) => {
    res.render('role_pengguna');  // Merender file 'roleSelection.ejs'
});

// Menjalankan server
app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
});
