    // models/Program.js
    const db = require('../config/database'); // Mengimpor pool koneksi database

    class Program {
        /**
         * Membuat program volunteer baru di database.
         * @param {string} title - Judul program.
         * @param {string} center - Pusat volunteer.
         * @param {number} quota - Kuota volunteer.
         * @param {string} duration - Durasi program.
         * @param {string} startDate - Tanggal mulai pendaftaran (format YYYY-MM-DD).
         * @param {string} endDate - Tanggal berakhir pendaftaran (format YYYY-MM-DD).
         * @param {string} description - Deskripsi program.
         * @param {number} createdByUserId - ID pengguna yang membuat program.
         * @returns {Promise<number>} ID program yang baru dibuat.
         */
        static async create(title, center, quota, duration, startDate, endDate, description, createdByUserId) {
            const [result] = await db.execute(
                'INSERT INTO programs (title, center, quota, duration, start_date, end_date, description, created_by_user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [title, center, quota, duration, startDate, endDate, description, createdByUserId]
            );
            return result.insertId;
        }

        /**
         * Mengambil semua program volunteer dari database.
         * @returns {Promise<Array<object>>} Array objek program.
         */
        static async getAll() {
            const [rows] = await db.execute('SELECT * FROM programs');
            return rows;
        }

        /**
         * Mencari program berdasarkan ID.
         * @param {number} id - ID program yang akan dicari.
         * @returns {Promise<object|undefined>} Objek program jika ditemukan, atau undefined.
         */
        static async findById(id) {
            const [rows] = await db.execute('SELECT * FROM programs WHERE id = ?', [id]);
            return rows[0];
        }

        /**
         * Memperbarui detail program volunteer.
         * @param {number} id - ID program yang akan diperbarui.
         * @param {string} title - Judul program baru.
         * @param {string} center - Pusat volunteer baru.
         * @param {number} quota - Kuota volunteer baru.
         * @param {string} duration - Durasi program baru.
         * @param {string} startDate - Tanggal mulai pendaftaran baru.
         * @param {string} endDate - Tanggal berakhir pendaftaran baru.
         * @param {string} description - Deskripsi program baru.
         * @returns {Promise<number>} Jumlah baris yang terpengaruh.
         */
        static async update(id, title, center, quota, duration, startDate, endDate, description) {
            const [result] = await db.execute(
                'UPDATE programs SET title = ?, center = ?, quota = ?, duration = ?, start_date = ?, end_date = ?, description = ? WHERE id = ?',
                [title, center, quota, duration, startDate, endDate, description, id]
            );
            return result.affectedRows;
        }

        /**
         * Menghapus program volunteer berdasarkan ID.
         * @param {number} id - ID program yang akan dihapus.
         * @returns {Promise<number>} Jumlah baris yang terpengaruh.
         */
        static async delete(id) {
            const [result] = await db.execute('DELETE FROM programs WHERE id = ?', [id]);
            return result.affectedRows;
        }

        // --- Metode tambahan (opsional) ---

        /**
         * Mencari program berdasarkan kata kunci di judul atau deskripsi.
         * @param {string} keyword - Kata kunci pencarian.
         * @returns {Promise<Array<object>>} Array objek program yang cocok.
         */
        static async search(keyword) {
            const [rows] = await db.execute(
                'SELECT * FROM programs WHERE title LIKE ? OR description LIKE ?',
                [`%${keyword}%`, `%${keyword}%`]
            );
            return rows;
        }

        /**
         * Memfilter program berdasarkan pusat atau status (misalnya, aktif/ditutup).
         * Ini akan membutuhkan kolom status di tabel atau logika tanggal.
         * @param {object} filters - Objek filter (misalnya { center: 'Migas Center', status: 'active' }).
         * @returns {Promise<Array<object>>} Array objek program yang difilter.
         */
        static async filter(filters) {
            let query = 'SELECT * FROM programs WHERE 1=1';
            const params = [];

            if (filters.center) {
                query += ' AND center = ?';
                params.push(filters.center);
            }
            // Tambahkan logika filter lain sesuai kebutuhan (misalnya berdasarkan tanggal, status)

            const [rows] = await db.execute(query, params);
            return rows;
        }
    }

    module.exports = Program; // Mengekspor kelas Program
    