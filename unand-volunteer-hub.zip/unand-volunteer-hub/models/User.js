    // models/User.js
    const db = require('../config/database'); // Mengimpor pool koneksi database
    const bcrypt = require('bcryptjs');     // Mengimpor bcryptjs untuk hashing password

    class User {
        /**
         * Membuat pengguna baru di database.
         * Password akan di-hash sebelum disimpan.
         * @param {string} nim - NIM pengguna.
         * @param {string} username - Username pengguna.
         * @param {string} password - Password pengguna (plain text).
         * @param {string} role - Peran pengguna (mahasiswa, pengurus, admin).
         * @returns {Promise<number>} ID pengguna yang baru dibuat.
         */
        static async create(nim, username, password, role) {
            // Hashing password sebelum disimpan ke database untuk keamanan
            const hashedPassword = await bcrypt.hash(password, 10); // 10 adalah salt rounds
            const [result] = await db.execute(
                'INSERT INTO users (nim, username, password, role) VALUES (?, ?, ?, ?)',
                [nim, username, hashedPassword, role]
            );
            return result.insertId; // Mengembalikan ID dari baris yang baru dimasukkan
        }

        /**
         * Mencari pengguna berdasarkan username.
         * @param {string} username - Username yang akan dicari.
         * @returns {Promise<object|undefined>} Objek pengguna jika ditemukan, atau undefined.
         */
        static async findByUsername(username) {
            const [rows] = await db.execute('SELECT * FROM users WHERE username = ?', [username]);
            return rows[0]; // Mengembalikan baris pertama (objek user) atau undefined jika tidak ada
        }

        /**
         * Mencari pengguna berdasarkan ID.
         * @param {number} id - ID pengguna yang akan dicari.
         * @returns {Promise<object|undefined>} Objek pengguna jika ditemukan, atau undefined.
         */
        static async findById(id) {
            const [rows] = await db.execute('SELECT * FROM users WHERE id = ?', [id]);
            return rows[0];
        }

        /**
         * Membandingkan plain text password dengan hashed password.
         * @param {string} plainPassword - Password plain text yang dimasukkan pengguna.
         * @param {string} hashedPassword - Password yang sudah di-hash dari database.
         * @returns {Promise<boolean>} True jika cocok, false jika tidak.
         */
        static async comparePassword(plainPassword, hashedPassword) {
            return await bcrypt.compare(plainPassword, hashedPassword);
        }

        // --- Metode tambahan untuk fungsionalitas CRUD Admin (opsional) ---

        /**
         * Mengambil semua pengguna dari database.
         * @returns {Promise<Array<object>>} Array objek pengguna (tanpa password).
         */
        static async getAllUsers() {
            const [rows] = await db.execute('SELECT id, nim, username, role, created_at FROM users');
            return rows;
        }

        /**
         * Memperbarui peran (role) pengguna berdasarkan ID.
         * @param {number} id - ID pengguna yang akan diperbarui.
         * @param {string} newRole - Peran baru pengguna.
         * @returns {Promise<number>} Jumlah baris yang terpengaruh.
         */
        static async updateRole(id, newRole) {
            const [result] = await db.execute('UPDATE users SET role = ? WHERE id = ?', [newRole, id]);
            return result.affectedRows;
        }

        /**
         * Menghapus pengguna berdasarkan ID.
         * @param {number} id - ID pengguna yang akan dihapus.
         * @returns {Promise<number>} Jumlah baris yang terpengaruh.
         */
        static async delete(id) {
            const [result] = await db.execute('DELETE FROM users WHERE id = ?', [id]);
            return result.affectedRows;
        }
    }

    module.exports = User; // Mengekspor kelas User
    