    // utils/authUtils.js

    // Anda bisa menambahkan fungsi-fungsi terkait autentikasi di sini.
    // Contoh: Fungsi untuk membuat JSON Web Token (JWT) setelah login berhasil
    // (Membutuhkan library 'jsonwebtoken' yang belum diinstal, jika ingin digunakan)

    /**
     * Menghasilkan token autentikasi dummy untuk tujuan prototipe.
     * Di aplikasi nyata, ini akan membuat JWT yang aman.
     * @param {object} user - Objek pengguna yang terautentikasi.
     * @returns {string} Token dummy.
     */
    function generateAuthToken(user) {
        // Contoh sederhana:
        // const jwt = require('jsonwebtoken');
        // return jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
        return `dummy_token_for_${user.username}_role_${user.role}`;
    }

    /**
     * Memverifikasi token autentikasi dummy.
     * Di aplikasi nyata, ini akan memverifikasi JWT.
     * @param {string} token - Token yang akan diverifikasi.
     * @returns {object|null} Objek pengguna yang didekode jika valid, atau null.
     */
    function verifyAuthToken(token) {
        // Contoh sederhana:
        // const jwt = require('jsonwebtoken');
        // try {
        //     return jwt.verify(token, process.env.JWT_SECRET);
        // } catch (error) {
        //     return null;
        // }
        if (token.startsWith('dummy_token_for_')) {
            const parts = token.split('_');
            return { username: parts[3], role: parts[5] };
        }
        return null;
    }


    module.exports = {
        generateAuthToken,
        verifyAuthToken
    };
    