    // app.js
    const express = require('express');
    const path = require('path');
    const cors = require('cors');
    const apiRoutes = require('./routes'); // Mengimpor router utama API dari folder routes (path ini benar karena routes/ ada di root)

    const app = express();

    // --- Konfigurasi Template Engine (EJS) ---
    app.set('view engine', 'ejs');
    app.set('views', path.join(__dirname, 'views')); // views/ ada di root

    // --- Middleware Global ---
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.use(cors());

    // --- Melayani File Statis dari public/ ---
    // Ini adalah baris yang memastikan Express melayani file dari folder 'public'
    app.use(express.static(path.join(__dirname, 'public'))); // public/ ada di root

    // --- Definisi Rute API ---
    app.use('/api', apiRoutes);

    // --- Rute Utama untuk Melayani Halaman Frontend (Sekarang menggunakan EJS) ---
    app.get('/', (req, res) => {
        res.render('auth/role_selection'); // Merender template EJS
    });

    // --- Penanganan Error ---
    app.use((req, res, next) => {
        res.status(404).render('error', { message: "Maaf, halaman tidak ditemukan!", statusCode: 404 });
    });

    app.use((err, req, res, next) => {
        console.error(err.stack);
        res.status(500).render('error', { message: 'Terjadi kesalahan pada server!', statusCode: 500 });
    });

    module.exports = app;
    