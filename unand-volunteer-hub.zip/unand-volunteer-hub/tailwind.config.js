    /** @type {import('tailwindcss').Config} */
    module.exports = {
      content: [
        // Pastikan baris ini ada dan benar
        "./views/**/*.ejs", // Memindai semua file .ejs di dalam folder views dan subfoldernya
        "./public/js/**/*.js", // Jika Anda memiliki JS yang menambahkan kelas Tailwind secara dinamis
        // Tambahkan juga jika Anda memiliki file HTML statis di public/
        "./public/**/*.html",
      ],
      theme: {
        extend: {},
      },
      plugins: [],
    }
    