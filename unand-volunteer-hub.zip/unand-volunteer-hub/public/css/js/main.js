// State management for current user role
let currentUserRole = "guest"; // 'guest', 'mahasiswa', 'pengurus', 'admin'
let selectedRoleForLogin = null; // Stores the role selected on the initial page

// Get elements
const sidebarNavLinksContainer = document.getElementById("sidebar-nav-links");
const contentSections = document.querySelectorAll(".content-section");
const mainSidebar = document.getElementById("main-sidebar");
const toggleSidebarBtn = document.getElementById("toggle-sidebar-btn");
const sidebarRoleDisplay = document.getElementById("sidebar-role-display");

const loginTitle = document.getElementById("login-title");
const loginSubtitle = document.getElementById("login-subtitle");

const customNotification = document.getElementById("custom-notification");

// Define navigation links for each role with icons (using Font Awesome classes)
const navLinks = {
  guest: [], // Guest role has no sidebar links
  mahasiswa: [
    {
      text: "Dashboard",
      sectionId: "dashboard-mahasiswa",
      icon: "fas fa-home",
    },
    {
      text: "Program Volunteer",
      sectionId: "mahasiswa-view-programs-section",
      icon: "fas fa-bullhorn",
    },
    {
      text: "Status Aplikasi",
      sectionId: "mahasiswa-track-application-section",
      icon: "fas fa-clipboard-list",
    },
    {
      text: "Kalender Kegiatan",
      sectionId: "mahasiswa-view-calendar-section",
      icon: "fas fa-calendar-alt",
    },
    {
      text: "Notifikasi",
      sectionId: "mahasiswa-view-announcements-section",
      icon: "fas fa-bell",
    },
    {
      text: "Dokumen Saya",
      sectionId: "mahasiswa-document-status-section",
      icon: "fas fa-file-alt",
    },
    {
      text: "Bantuan Surat Motivasi ✨",
      sectionId: "mahasiswa-motivation-letter-section",
      icon: "fas fa-magic",
    },
  ],
  pengurus: [
    {
      text: "Dashboard",
      sectionId: "dashboard-pengurus",
      icon: "fas fa-tachometer-alt",
    },
    {
      text: "Buat Program Baru",
      sectionId: "pengurus-create-program-section",
      icon: "fas fa-plus-circle",
    },
    {
      text: "Manajemen Seleksi",
      sectionId: "pengurus-update-selection-section",
      icon: "fas fa-users-cog",
    },
    {
      text: "Detail Program",
      sectionId: "pengurus-view-edit-program-section",
      icon: "fas fa-info-circle",
    },
    {
      text: "Jadwal Seleksi",
      sectionId: "pengurus-view-schedule-section",
      icon: "fas fa-calendar-check",
    },
    {
      text: "Kirim Pengumuman",
      sectionId: "pengurus-send-announcement-section",
      icon: "fas fa-paper-plane",
    },
    {
      text: "Validasi Dokumen",
      sectionId: "pengurus-validate-documents-section",
      icon: "fas fa-check-double",
    },
    {
      text: "Statistik & Analitik",
      sectionId: "pengurus-analytics-report-section",
      icon: "fas fa-chart-bar",
    },
  ],
  admin: [
    { text: "Dashboard", sectionId: "dashboard-admin", icon: "fas fa-cogs" },
    {
      text: "Manajemen Program",
      sectionId: "admin-program-overview-section",
      icon: "fas fa-tasks",
    },
    {
      text: "Overview Seleksi",
      sectionId: "admin-selection-overview-section",
      icon: "fas fa-user-check",
    },
    {
      text: "Manajemen Jadwal",
      sectionId: "admin-global-schedule-section",
      icon: "fas fa-calendar-plus",
    },
    {
      text: "Log Pengumuman",
      sectionId: "admin-announcement-log-section",
      icon: "fas fa-history",
    },
    {
      text: "Validasi Dokumen",
      sectionId: "admin-document-validation-overview-section",
      icon: "fas fa-file-contract",
    },
    {
      text: "Analitik Komprehensif",
      sectionId: "admin-comprehensive-analytics-section",
      icon: "fas fa-chart-line",
    },
    {
      text: "Saran Konten FAQ ✨",
      sectionId: "admin-faq-management-section",
      icon: "fas fa-lightbulb",
    },
  ],
};

// Function to show a specific content section and hide others
function showSection(sectionId) {
  contentSections.forEach((section) => {
    section.classList.add("hidden");
  });
  const targetSection = document.getElementById(sectionId);
  if (targetSection) {
    targetSection.classList.remove("hidden");
  } else {
    console.error("Section not found:", sectionId);
  }

  // Update active state in sidebar
  document.querySelectorAll(".sidebar-nav-item").forEach((item) => {
    item.classList.remove("active");
  });
  const activeLink = document.querySelector(`[data-section-id="${sectionId}"]`);
  if (activeLink) {
    activeLink.classList.add("active");
  }
  // Close sidebar after selecting a menu item (for mobile/overlay)
  if (window.innerWidth < 1024 && mainSidebar.classList.contains("open")) {
    // Only close on small screens if open
    toggleSidebar();
  }
}

// Function to toggle sidebar visibility (for mobile/small screens)
function toggleSidebar() {
  mainSidebar.classList.toggle("open");
  // Hide/show toggle button based on sidebar state on small screens
  if (window.innerWidth < 1024) {
    if (mainSidebar.classList.contains("open")) {
      toggleSidebarBtn.classList.add("hidden");
    } else {
      toggleSidebarBtn.classList.remove("hidden");
    }
  }
}

// Function to update the sidebar navigation based on the current user role
function updateSidebar(role) {
  sidebarNavLinksContainer.innerHTML = ""; // Clear existing links
  const links = navLinks[role];
  if (links) {
    // Ensure links exist for the role
    links.forEach((link) => {
      const div = document.createElement("div");
      div.classList.add("sidebar-nav-item");
      div.setAttribute("data-section-id", link.sectionId); // Custom attribute to link to section

      div.innerHTML = `<i class="${link.icon}"></i> <span>${link.text}</span>`;

      div.addEventListener("click", (e) => {
        e.preventDefault();
        showSection(link.sectionId);
      });
      sidebarNavLinksContainer.appendChild(div);
    });
  }

  // Update role display in sidebar footer
  sidebarRoleDisplay.textContent = `Login sebagai: ${
    role.charAt(0).toUpperCase() + role.slice(1)
  }`;

  // Show/hide sidebar and toggle button based on role
  if (role === "guest") {
    mainSidebar.classList.remove("open"); // Ensure sidebar is closed
    mainSidebar.classList.add("hidden"); // Fully hide sidebar
    toggleSidebarBtn.classList.add("hidden"); // Hide toggle button
  } else {
    mainSidebar.classList.remove("hidden"); // Show sidebar (but initially closed on mobile, open on desktop)
    // Adjust visibility of toggle button based on screen size
    if (window.innerWidth < 1024) {
      toggleSidebarBtn.classList.remove("hidden"); // Show toggle button on mobile
      mainSidebar.classList.remove("open"); // Ensure sidebar is closed on mobile by default
    } else {
      toggleSidebarBtn.classList.add("hidden"); // Hide toggle button on desktop
      mainSidebar.classList.add("open"); // Ensure sidebar is open on desktop by default
    }
  }
}

// Custom Notification Function
function showNotification(message, type = "info", duration = 3000) {
  customNotification.textContent = message;
  customNotification.className = ""; // Clear existing classes
  customNotification.classList.add("hidden"); // Hide before showing to reset animation
  customNotification.classList.add(type); // Add type class (success, error, info)
  customNotification.classList.remove("hidden"); // Show element
  setTimeout(() => {
    customNotification.classList.add("show"); // Trigger animation
  }, 10); // Small delay for CSS transition to work

  setTimeout(() => {
    customNotification.classList.remove("show"); // Start hide animation
    customNotification.addEventListener("transitionend", function handler() {
      customNotification.classList.add("hidden"); // Fully hide after animation
      customNotification.removeEventListener("transitionend", handler);
    });
  }, duration);
}

// Step 1: User selects a role
function selectRole(role) {
  selectedRoleForLogin = role;
  loginTitle.textContent = `Login sebagai ${
    role.charAt(0).toUpperCase() + role.slice(1)
  }`;
  loginSubtitle.textContent = `Silakan masukkan kredensial ${role} Anda.`;
  showSection("login-section");
  // Hide toggle button on auth pages
  toggleSidebarBtn.classList.add("hidden");
}

// Step 2: User logs in
document.getElementById("login-form").addEventListener("submit", function (e) {
  e.preventDefault(); // Prevent default form submission
  // In a real app, you'd validate credentials against the selectedRoleForLogin here.
  // For this UI mock, we just simulate successful login and proceed.
  currentUserRole = selectedRoleForLogin; // Set the actual current role
  updateSidebar(currentUserRole);
  showSection(`dashboard-${currentUserRole}`); // Go to dashboard after login
  showNotification(
    `Selamat datang, ${
      currentUserRole.charAt(0).toUpperCase() + currentUserRole.slice(1)
    }!`,
    "success"
  );
});

// Step 2.5: User signs up
document.getElementById("signup-form").addEventListener("submit", function (e) {
  e.preventDefault(); // Prevent default form submission
  // In a real app, you'd handle user registration here.
  // For this UI mock, we just show a message and go back to login.
  showNotification(
    "Pendaftaran berhasil! Silakan login dengan akun Anda.",
    "success"
  );
  showSection("login-section");
});

// Step 3: User logs out
function logout() {
  currentUserRole = "guest";
  selectedRoleForLogin = null; // Reset selected role
  updateSidebar(currentUserRole);
  showSection("role-selection-section"); // Go back to role selection page
  // Ensure sidebar is closed and toggle button is hidden on logout
  mainSidebar.classList.remove("open");
  toggleSidebarBtn.classList.add("hidden");
  showNotification("Anda telah berhasil logout.", "info");
}

// Handle window resize to adjust sidebar visibility and toggle button
window.addEventListener("resize", function () {
  updateSidebar(currentUserRole); // Re-evaluate sidebar state on resize
});

// Initial setup on page load
document.addEventListener("DOMContentLoaded", function () {
  updateSidebar(currentUserRole); // Initialize sidebar for guest (empty)
  showSection("role-selection-section"); // Show the role selection page initially
});

// --- Gemini API Integration ---
const apiKey = "AIzaSyDVo3uGC4EKGJwJa2v_TJsJ9GKxuswcPH4"; // If you want to use models other than gemini-2.0-flash or imagen-3.0-generate-002, provide an API key here. Otherwise, leave this as-is.

async function callGeminiAPI(prompt, outputElementId, loadingElementId) {
  const outputElement = document.getElementById(outputElementId);
  const loadingElement = document.getElementById(loadingElementId);
  const responseContainer = outputElement.closest(".bg-gray-50"); // Get the parent container to show/hide

  outputElement.textContent = ""; // Clear previous output
  responseContainer.classList.add("hidden"); // Hide container initially
  loadingElement.classList.remove("hidden"); // Show loading indicator

  let chatHistory = [];
  chatHistory.push({ role: "user", parts: [{ text: prompt }] });
  const payload = { contents: chatHistory };
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const result = await response.json();

    if (
      result.candidates &&
      result.candidates.length > 0 &&
      result.candidates[0].content &&
      result.candidates[0].content.parts &&
      result.candidates[0].content.parts.length > 0
    ) {
      const text = result.candidates[0].content.parts[0].text;
      outputElement.textContent = text;
      responseContainer.classList.remove("hidden"); // Show container with response
    } else {
      outputElement.textContent =
        "Error: Tidak dapat menghasilkan respons. Struktur respons tidak terduga.";
      responseContainer.classList.remove("hidden");
      console.error("Unexpected API response structure:", result);
      showNotification(
        "Terjadi kesalahan saat memproses permintaan AI.",
        "error"
      );
    }
  } catch (error) {
    outputElement.textContent = `Error: Terjadi kesalahan saat memanggil API. (${error.message})`;
    responseContainer.classList.remove("hidden");
    console.error("Error calling Gemini API:", error);
    showNotification(
      "Gagal terhubung ke layanan AI. Periksa koneksi Anda.",
      "error"
    );
  } finally {
    loadingElement.classList.add("hidden"); // Hide loading indicator
  }
}

// Mahasiswa: Bantuan Surat Motivasi
async function generateMotivationLetter() {
  const draft = document.getElementById("motivation-letter-draft").value;
  if (!draft.trim()) {
    showNotification(
      "Mohon masukkan draf surat motivasi Anda terlebih dahulu.",
      "info"
    );
    return;
  }
  const prompt = `Perbaiki dan sempurnakan draf surat motivasi berikut agar lebih profesional, persuasif, dan menarik. Fokus pada tata bahasa, pilihan kata, dan struktur. Pastikan tetap dalam konteks pendaftaran volunteer perpustakaan Unand. Draf: \n\n"${draft}"`;
  await callGeminiAPI(
    prompt,
    "motivation-letter-output",
    "motivation-letter-loading"
  );
}

// Pengurus: Draft Pengumuman Otomatis
async function generateAnnouncementDraft() {
  const keywords = document.getElementById("announcement-keywords").value;
  if (!keywords.trim()) {
    showNotification(
      "Mohon masukkan poin utama atau kata kunci untuk pengumuman.",
      "info"
    );
    return;
  }
  const prompt = `Buatlah draf pengumuman resmi untuk volunteer perpustakaan Unand berdasarkan poin-poin berikut: "${keywords}". Pastikan pengumuman memiliki salam pembuka, isi yang jelas, dan penutup yang sopan.`;
  await callGeminiAPI(prompt, "announcement-output", "announcement-loading");
}

// Admin: Saran Konten FAQ
async function generateFaqAnswer() {
  const question = document.getElementById("faq-question-input").value;
  if (!question.trim()) {
    showNotification("Mohon masukkan pertanyaan FAQ.", "info");
    return;
  }
  const prompt = `Berikan jawaban yang komprehensif dan mudah dimengerti untuk pertanyaan FAQ berikut terkait sistem pendaftaran volunteer perpustakaan Unand: "${question}".`;
  await callGeminiAPI(prompt, "faq-output", "faq-loading");
}
