    // config/database.js
    const mysql = require('mysql2/promise'); // Menggunakan mysql2/promise untuk async/await
    require('dotenv').config(); // Memuat variabel lingkungan dari .env

    // Membuat pool koneksi ke database MySQL
    const pool = mysql.createPool({
        host: process.env.DB_HOST,        // Host database (misalnya: localhost)
        user: process.env.DB_USER,        // Nama pengguna database (misalnya: root)
        password: process.env.DB_PASSWORD, // Kata sandi database
        database: process.env.DB_NAME,     // Nama database yang akan digunakan
        waitForConnections: true,         // Apakah pool akan menunggu koneksi tersedia jika semua sedang digunakan
        connectionLimit: 10,              // Jumlah maksimum koneksi yang diizinkan dalam pool
        queueLimit: 0                     // Jumlah permintaan yang dapat di-queue jika semua koneksi sedang digunakan
    });

    // Menguji koneksi ke database saat aplikasi dimulai
    pool.getConnection()
        .then(connection => {
            console.log('Terhubung ke database MySQL: ' + process.env.DB_NAME);
            connection.release(); // Melepaskan koneksi kembali ke pool setelah pengujian
        })
        .catch(err => {
            console.error('Gagal terhubung ke database MySQL:', err.message);
            console.error('Pastikan MySQL server berjalan dan kredensial di file .env sudah benar.');
            process.exit(1); // Keluar dari aplikasi jika gagal terhubung ke database
        });

    module.exports = pool; // Mengekspor pool koneksi agar dapat digunakan di bagian lain aplikasi
    