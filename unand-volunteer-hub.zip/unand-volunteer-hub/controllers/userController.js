    // controllers/userController.js
    const User = require('../models/User'); // Mengimpor model User

    /**
     * Mengambil semua pengguna dari database.
     * (Biasanya hanya dapat diakses oleh Admin)
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.getAllUsers = async (req, res) => {
        try {
            // Mengambil semua pengguna dari model User
            // Dalam aplikasi nyata, Anda mungkin ingin membatasi kolom yang diambil
            // (misalnya, tidak menyertakan password hash)
            const users = await User.getAllUsers();
            res.status(200).json({ success: true, data: users });
        } catch (error) {
            console.error('Error fetching users:', error);
            res.status(500).json({ success: false, message: 'Gagal mengambil data pengguna.' });
        }
    };

    /**
     * Memperbarui peran (role) pengguna tertentu.
     * (Biasanya hanya dapat diakses oleh Admin)
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.updateUserRole = async (req, res) => {
        const { id } = req.params; // ID pengguna dari parameter URL
        const { role } = req.body; // Peran baru dari body request

        // Validasi input dasar
        if (!role) {
            return res.status(400).json({ message: 'Peran baru harus disediakan.' });
        }

        try {
            const affectedRows = await User.updateRole(id, role);
            if (affectedRows === 0) {
                return res.status(404).json({ message: 'Pengguna tidak ditemukan atau tidak ada perubahan peran.' });
            }
            res.status(200).json({ message: 'Peran pengguna berhasil diperbarui!' });
        } catch (error) {
            console.error('Error updating user role:', error);
            res.status(500).json({ message: 'Gagal memperbarui peran pengguna.' });
        }
    };

    /**
     * Menghapus pengguna.
     * (Biasanya hanya dapat diakses oleh Admin)
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.deleteUser = async (req, res) => {
        const { id } = req.params;
        try {
            const affectedRows = await User.delete(id);
            if (affectedRows === 0) {
                return res.status(404).json({ message: 'Pengguna tidak ditemukan.' });
            }
            res.status(200).json({ message: 'Pengguna berhasil dihapus!' });
        } catch (error) {
            console.error('Error deleting user:', error);
            res.status(500).json({ message: 'Gagal menghapus pengguna.' });
        }
    };
    