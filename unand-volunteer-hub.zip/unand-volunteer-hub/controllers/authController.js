    // controllers/authController.js
    const User = require('../models/User'); // Mengimpor model User

    /**
     * Menangani proses login pengguna.
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.login = async (req, res) => {
        const { username, password, role } = req.body; // Menerima username, password, dan role dari body request

        // Validasi input dasar
        if (!username || !password || !role) {
            return res.status(400).json({ message: 'Username, password, dan role harus diisi.' });
        }

        try {
            // Mencari pengguna berdasarkan username
            const user = await User.findByUsername(username);

            // Jika pengguna tidak ditemukan
            if (!user) {
                return res.status(401).json({ message: 'Username tidak ditemukan.' });
            }

            // Membandingkan password yang dimasukkan dengan hashed password di database
            const isMatch = await User.comparePassword(password, user.password);

            // Jika password tidak cocok
            if (!isMatch) {
                return res.status(401).json({ message: 'Password salah.' });
            }

            // Memverifikasi apakah peran yang dipilih sesuai dengan peran pengguna di database
            if (user.role !== role) {
                return res.status(403).json({ message: `Anda tidak memiliki akses sebagai ${role}. Peran Anda adalah ${user.role}.` });
            }

            // Login berhasil
            // Di aplikasi nyata, di sini Anda akan membuat dan mengirimkan token JWT (JSON Web Token)
            // Untuk prototipe ini, kita hanya mengirimkan pesan sukses dan data pengguna dasar
            res.status(200).json({
                message: 'Login berhasil!',
                user: {
                    id: user.id,
                    username: user.username,
                    role: user.role
                }
            });

        } catch (error) {
            // Menangkap dan mencatat error server
            console.error('Error during login:', error);
            res.status(500).json({ message: 'Terjadi kesalahan server saat login.' });
        }
    };

    /**
     * Menangani proses pendaftaran pengguna baru.
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.register = async (req, res) => {
        const { nim, username, password } = req.body; // Menerima NIM, username, dan password dari body request

        // Validasi input dasar
        if (!nim || !username || !password) {
            return res.status(400).json({ message: 'NIM, username, dan password harus diisi.' });
        }

        // Secara default, pendaftaran dari frontend ini diasumsikan untuk peran 'mahasiswa'
        const role = 'mahasiswa';

        try {
            // Membuat pengguna baru melalui model User
            const userId = await User.create(nim, username, password, role);
            res.status(201).json({ message: 'Pendaftaran berhasil!', userId }); // Mengembalikan ID pengguna yang baru dibuat
        } catch (error) {
            console.error('Error during registration:', error);
            // Menangani error jika NIM atau username sudah ada (duplicate entry)
            if (error.message.includes('Duplicate entry')) {
                return res.status(409).json({ message: 'NIM atau Username sudah terdaftar. Silakan gunakan yang lain.' });
            }
            res.status(500).json({ message: 'Terjadi kesalahan server saat pendaftaran.' });
        }
    };
    