    // controllers/programController.js
    const Program = require('../models/Program'); // Mengimpor model Program

    /**
     * Membuat program volunteer baru.
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.createProgram = async (req, res) => {
        // Menerima data program dari body request
        const { title, center, quota, duration, start_date, end_date, description, created_by_user_id } = req.body;

        // Validasi input dasar
        if (!title || !center || !quota || !start_date || !end_date || !description || !created_by_user_id) {
            return res.status(400).json({ message: 'Semua bidang program harus diisi.' });
        }

        try {
            // Membuat program baru melalui model Program
            const newProgramId = await Program.create(title, center, quota, duration, start_date, end_date, description, created_by_user_id);
            res.status(201).json({ message: 'Program berhasil dibuat!', programId: newProgramId });
        } catch (error) {
            console.error('Error creating program:', error);
            res.status(500).json({ message: 'Gagal membuat program.' });
        }
    };

    /**
     * Mengambil semua program volunteer.
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.getAllPrograms = async (req, res) => {
        try {
            // Mengambil semua program dari model Program
            const programs = await Program.getAll();
            res.status(200).json({ success: true, data: programs });
        } catch (error) {
            console.error('Error fetching programs:', error);
            res.status(500).json({ success: false, message: 'Gagal mengambil data program.' });
        }
    };

    /**
     * Mengambil program volunteer berdasarkan ID.
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.getProgramById = async (req, res) => {
        const { id } = req.params; // Mengambil ID dari parameter URL
        try {
            const program = await Program.findById(id);
            if (!program) {
                return res.status(404).json({ message: 'Program tidak ditemukan.' });
            }
            res.status(200).json({ success: true, data: program });
        } catch (error) {
            console.error('Error fetching program by ID:', error);
            res.status(500).json({ success: false, message: 'Gagal mengambil data program.' });
        }
    };

    /**
     * Memperbarui detail program volunteer.
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.updateProgram = async (req, res) => {
        const { id } = req.params;
        const { title, center, quota, duration, start_date, end_date, description } = req.body;

        // Validasi input dasar
        if (!title || !center || !quota || !start_date || !end_date || !description) {
            return res.status(400).json({ message: 'Semua bidang program harus diisi.' });
        }

        try {
            const affectedRows = await Program.update(id, title, center, quota, duration, start_date, end_date, description);
            if (affectedRows === 0) {
                return res.status(404).json({ message: 'Program tidak ditemukan atau tidak ada perubahan.' });
            }
            res.status(200).json({ message: 'Program berhasil diperbarui!' });
        } catch (error) {
            console.error('Error updating program:', error);
            res.status(500).json({ message: 'Gagal memperbarui program.' });
        }
    };

    /**
     * Menghapus program volunteer.
     * @param {object} req - Objek request Express.
     * @param {object} res - Objek response Express.
     */
    exports.deleteProgram = async (req, res) => {
        const { id } = req.params;
        try {
            const affectedRows = await Program.delete(id);
            if (affectedRows === 0) {
                return res.status(404).json({ message: 'Program tidak ditemukan.' });
            }
            res.status(200).json({ message: 'Program berhasil dihapus!' });
        } catch (error) {
            console.error('Error deleting program:', error);
            res.status(500).json({ message: 'Gagal menghapus program.' });
        }
    };
    